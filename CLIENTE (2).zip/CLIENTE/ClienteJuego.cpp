// ClienteJuego.cpp
#include "ClienteJuego.h"
#include "Mazo.h"
#include <iostream>
#include <thread>

ClienteJuego::ClienteJuego(const std::string& nombre) : nombreJugador(nombre), socket_fd(INVALID_SOCKET), conectado(false) {}

ClienteJuego::~ClienteJuego() {
    desconectar();
}

bool ClienteJuego::conectar(const std::string& ip, int puerto) {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "WSAStartup failed.\n";
        return false;
    }

    // Crear el socket
    if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
        std::cerr << "Error al crear el socket: " << WSAGetLastError() << std::endl;
        WSACleanup();
        return false;
    }

    // Configurar la dirección del servidor
    sockaddr_in direccion_servidor;
    direccion_servidor.sin_family = AF_INET;
    direccion_servidor.sin_port = htons(puerto);
    inet_pton(AF_INET, ip.c_str(), &direccion_servidor.sin_addr);

    // Conectar al servidor
    if (connect(socket_fd, (struct sockaddr*)&direccion_servidor, sizeof(direccion_servidor)) == SOCKET_ERROR) {
        std::cerr << "Error al conectar: " << WSAGetLastError() << std::endl;
        closesocket(socket_fd);
        WSACleanup();
        return false;
    }

    // Enviar nombre del jugador al servidor
    if (send(socket_fd, nombreJugador.c_str(), nombreJugador.length(), 0) == SOCKET_ERROR) {
        std::cerr << "Error al enviar nombre: " << WSAGetLastError() << std::endl;
        closesocket(socket_fd);
        WSACleanup();
        return false;
    }

    conectado = true;
    return true;
}

void ClienteJuego::desconectar() {
    if (socket_fd != INVALID_SOCKET) {
        closesocket(socket_fd);
        socket_fd = INVALID_SOCKET;
    }
    conectado = false;
    WSACleanup();
}

void ClienteJuego::enviarComando(const std::string& comando) {
    if (!conectado) return;
    
    if (send(socket_fd, comando.c_str(), comando.length(), 0) == SOCKET_ERROR) {
        std::cerr << "Error al enviar comando: " << WSAGetLastError() << std::endl;
        desconectar();
    }
}

void ClienteJuego::escucharServidor(std::function<void(const std::string&)> manejadorMensajes) {
    char buffer[1024];
    int bytes_recibidos;
    
    while (conectado) {
        bytes_recibidos = recv(socket_fd, buffer, sizeof(buffer), 0);
        if (bytes_recibidos <= 0) {
            std::cerr << "Error o conexion cerrada por el servidor\n";
            desconectar();
            break;
        }
        
        std::string mensaje(buffer, bytes_recibidos);
        manejadorMensajes(mensaje);
    }
}

bool ClienteJuego::estaConectado() const {
    return conectado;
}