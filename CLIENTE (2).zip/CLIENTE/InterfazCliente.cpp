// InterfazCliente.cpp
#include "InterfazCliente.h"
#include "Utilidades.h"
#include <iostream>
#include <sstream>

InterfazCliente::InterfazCliente(ClienteJuego& cliente) : cliente(cliente), jugadorIndex(-1) {}

void InterfazCliente::iniciar() {
    // Configurar callback para mensajes del servidor
    cliente.escucharServidor([this](const std::string& mensaje) {
        this->procesarComando(mensaje);
    });
    
    mostrarMenuPrincipal();
}

void InterfazCliente::mostrarMenuPrincipal() {
    while (true) {
        std::cout << "\n=== MENU PRINCIPAL ===" << std::endl;
        std::cout << "1. Ver mi mano" << std::endl;
        std::cout << "2. Tirar carta" << std::endl;
        std::cout << "3. Ver estado del juego" << std::endl;
        std::cout << "4. Salir" << std::endl;
        
        int opcion = obtenerEntradaNumerica(1, 4, "Seleccione una opción: ");
        
        switch (opcion) {
            case 1: mostrarMano(); break;
            case 2: {
                if (mano.empty()) {
                    std::cout << "No tienes cartas para tirar." << std::endl;
                    break;
                }
                int cartaIndex = obtenerEntradaNumerica(1, mano.size(), 
                    "Seleccione una carta (1-" + std::to_string(mano.size()) + "): ");
                cliente.enviarComando("TIRAR_CARTA " + std::to_string(cartaIndex - 1));
                break;
            }
            case 3: {
                std::cout << "\n=== ESTADO DEL JUEGO ===" << std::endl;
                std::cout << "Ronda: " << rondaActual << "/" << totalRondas << std::endl;
                std::cout << "Color de la ronda: " << colorRonda << std::endl;
                break;
            }
            case 4: return;
        }
    }
}

void InterfazCliente::mostrarMano() {
    std::cout << "\n=== TU MANO ===" << std::endl;
    for (size_t i = 0; i < mano.size(); ++i) {
        std::cout << (i + 1) << ". " << mano[i].toString() << std::endl;
    }
}

void InterfazCliente::procesarComando(const std::string& comando) {
    std::istringstream iss(comando);
    std::string tipo;
    iss >> tipo;
    
    if (tipo == "MANO") {
        mano.clear();
        std::string color;
        int numero;
        while (iss >> color >> numero) {
            mano.emplace_back(color, numero);
        }
    } 
    else if (tipo == "RONDA_INICIADA") {
        iss >> colorRonda;
        std::cout << "\n¡Nueva ronda iniciada! Color: " << colorRonda << std::endl;
    }
    else if (tipo == "CARTA_JUGADA") {
        int jugador;
        std::string color;
        int numero;
        iss >> jugador >> color >> numero;
        std::cout << "Jugador " << jugador << " tiró: " << color << " " << numero << std::endl;
    }
    else if (tipo == "RONDA_GANADA") {
        int jugador, puntos;
        iss >> jugador >> puntos;
        std::cout << "\n¡Jugador " << jugador << " ganó la ronda! Ahora tiene " << puntos << " puntos." << std::endl;
    }
    else if (tipo == "TURNO") {
        std::cout << "\n¡Es tu turno! Por favor selecciona una carta para tirar." << std::endl;
    }
    else if (tipo == "JUEGO_TERMINADO") {
        std::string ganador;
        std::getline(iss, ganador);
        std::cout << "\n¡EL JUEGO HA TERMINADO! Ganador: " << ganador << std::endl;
        exit(0);
    }
}

void InterfazCliente::actualizarEstado(const std::string& estado) {
    std::istringstream iss(estado);
    std::string tipo;
    iss >> tipo;
    
    if (tipo == "ESTADO_JUEGO") {
        char separador;
        iss >> rondaActual >> separador >> totalRondas >> colorRonda;
    }
}