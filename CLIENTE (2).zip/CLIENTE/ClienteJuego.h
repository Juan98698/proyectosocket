// ClienteJuego.h
#ifndef CLIENTE_JUEGO_H
#define CLIENTE_JUEGO_H

#include <winsock2.h>
#include <ws2tcpip.h>
#include <string>
#include <functional>

#pragma comment(lib, "ws2_32.lib")

class ClienteJuego {
private:
    SOCKET socket_fd;
    std::string nombreJugador;
    bool conectado;
    
public:
    ClienteJuego(const std::string& nombre);
    ~ClienteJuego();
    bool conectar(const std::string& ip, int puerto);
    void desconectar();
    void enviarComando(const std::string& comando);
    void escucharServidor(std::function<void(const std::string&)> manejadorMensajes);
    bool estaConectado() const;
};

#endif