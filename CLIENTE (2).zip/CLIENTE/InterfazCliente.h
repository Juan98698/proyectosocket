// InterfazCliente.h
#ifndef INTERFAZ_CLIENTE_H
#define INTERFAZ_CLIENTE_H

#include "ClienteJuego.h"
#include <functional>
#include <vector>

class InterfazCliente {
public:
    InterfazCliente(ClienteJuego& cliente);
    void iniciar();
    
private:
    ClienteJuego& cliente;
    int jugadorIndex;
    std::vector<Carta> mano;
    std::string colorRonda;
    int rondaActual;
    int totalRondas;
    
    void mostrarMenuPrincipal();
    void mostrarMano();
    void procesarComando(const std::string& comando);
    void actualizarEstado(const std::string& estado);
};

#endif