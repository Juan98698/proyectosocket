// main.cpp del cliente
#include "ClienteJuego.h"
#include "InterfazCliente.h"
#include "Utilidades.h"
#include <iostream>
#include <string>

int main() {
    setupConsole();
    
    std::string nombre;
    std::cout << "Ingrese su nombre: ";
    std::getline(std::cin, nombre);
    
    std::string ipServidor;
    std::cout << "IP del servidor (ej: 127.0.0.1): ";
    std::cin >> ipServidor;
    limpiarBufferEntrada();
    
    int puerto = obtenerEntradaNumerica(1024, 65535, "Puerto del servidor (ej: 12345): ");
    
    ClienteJuego cliente(nombre);
    if (!cliente.conectar(ipServidor, puerto)) {
        std::cerr << "Error al conectar al servidor." << std::endl;
        return 1;
    }
    
    InterfazCliente interfaz(cliente);
    interfaz.iniciar();
    
    return 0;
}