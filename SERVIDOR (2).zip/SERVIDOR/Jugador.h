#ifndef JUGADOR_H
#define JUGADOR_H

#include "Carta.h"
#include <vector>
#include <string>

class Jugador {
public:
    std::string nombre;
    std::vector<Carta> mano;
    std::vector<Carta> manoInicial;
    int puntuacion;
    int rondasGanadas;

    Jugador(std::string n);
    void mostrarMano();
    void mostrarManoInicial();
    Carta tirarCarta(int indice);
    bool tieneColor(const std::string& color) const;
    bool tieneCartas() const;
};

#endif