#ifndef SERVIDOR_JUEGO_H
#define SERVIDOR_JUEGO_H
#include <cstdlib>
#include "Juego.h"
#include <winsock2.h>
#include <ws2tcpip.h>
#include <vector>
#include <thread>
#include <mutex>
#include <memory>
#include <string>

#pragma comment(lib, "ws2_32.lib")

class ServidorJuego {
private:
    SOCKET servidor_fd;                      // Socket del servidor
    std::vector<SOCKET> clientes;            // Lista de sockets de clientes conectados
    std::vector<std::string> nombresJugadores; // Nombres de jugadores registrados
    std::unique_ptr<Juego> juego;            // Juego principal (manejado con smart pointer)
    bool juegoIniciado;                      // Flag de estado del juego
    std::mutex mtx;                          // Mutex para acceso thread-safe a clientes

    /**
     * Maneja la comunicación con un cliente específico en un hilo separado.
     * @param cliente_socket Socket del cliente a manejar.
     */
    void manejarCliente(SOCKET cliente_socket);

    /**
     * Envía un mensaje a todos los clientes conectados (thread-safe).
     * @param mensaje Mensaje a broadcastear.
     */
    void broadcast(const std::string& mensaje) {
        std::lock_guard<std::mutex> lock(mtx); // Bloquea el acceso a la lista de clientes
        for (SOCKET cliente : clientes) {
            if (send(cliente, mensaje.c_str(), mensaje.size(), 0) == SOCKET_ERROR) {
                std::cerr << "Error al enviar mensaje a cliente: " << WSAGetLastError() << std::endl;
            }
        }
    }

    /**
     * Envía un mensaje a un cliente específico.
     * @param cliente Socket del cliente destino.
     * @param mensaje Mensaje a enviar.
     */
    void enviarACliente(SOCKET cliente, const std::string& mensaje) {
        if (send(cliente, mensaje.c_str(), mensaje.size(), 0) == SOCKET_ERROR) {
            std::cerr << "Error al enviar mensaje: " << WSAGetLastError() << std::endl;
        }
    }

    /**
     * Procesa un comando recibido desde un cliente.
     * @param cliente Socket del cliente que envió el comando.
     * @param comando Comando a procesar (ej: "TIRAR_CARTA 1").
     */
    void procesarComando(SOCKET cliente, const std::string& comando);

public:
    ServidorJuego();
    ~ServidorJuego();

    /**
     * Inicia el servidor en el puerto especificado.
     * @param puerto Puerto de escucha (ej: 12345).
     */
    void iniciar(int puerto);

    /**
     * Detiene el servidor y libera recursos.
     */
    void detener();
};

#endif