#include "Carta.h"
#include <map>

Carta::Carta(std::string c, int n) : color(c), numero(n) {}

std::string Carta::toString() const {
    static const std::map<std::string, std::string> coloresAnsi = {
        {"Rojo", "\033[31m"},     // Rojo
        {"Azul", "\033[34m"},     // Azul
        {"Amarillo", "\033[33m"}, // Amarillo
        {"Verde", "\033[32m"}     // Verde
    };

    auto it = coloresAnsi.find(color);
    std::string codigoColor = (it != coloresAnsi.end()) ? it->second : "\033[0m";
    return codigoColor + color + " " + std::to_string(numero) + "\033[0m";
}