// main.cpp del Servidor
#include "ServidorJuego.h"
#include "Utilidades.h"
#include <iostream>
#include <string>

int main() {
    setupConsole();
    
    std::cout << "=== MODO SERVIDOR ===" << std::endl;
    std::cout << "Iniciando partida..." << std::endl;

    int puerto = obtenerEntradaNumerica(1024, 65535, "Ingrese el puerto para escuchar (ej: 12345): ");
    
    ServidorJuego servidor;
    servidor.iniciar(puerto);  // Bloquea hasta que el servidor termine

    return 0;
}