// Juego.cpp modificado
#include "Juego.h"
#include <sstream>

Juego::Juego(const std::vector<std::string>& nombresJugadores) : 
    rondaActual(1), indiceJugadorInicial(0), totalRondas(0) {
    for (const std::string& nombre : nombresJugadores) {
        jugadores.push_back(Jugador(nombre));
    }
    
    // Repartir cartas
    int cartasPorJugador = 36 / jugadores.size();
    totalRondas = cartasPorJugador;
    
    for (int i = 0; i < cartasPorJugador; ++i) {
        for (auto& jugador : jugadores) {
            Carta carta = mazo.robarCarta();
            jugador.mano.push_back(carta);
            jugador.manoInicial.push_back(carta);
        }
    }
}

void Juego::setNotificacionCallback(std::function<void(const std::string&)> callback) {
    notificar = callback;
}

void Juego::iniciarRonda(const std::string& color) {
    colorRonda = color;
    cartasJugadas.clear();
    notificarTodos("RONDA_INICIADA " + color);
}

void Juego::jugarCarta(int jugadorIndex, int cartaIndex) {
    if (jugadorIndex < 0 || jugadorIndex >= jugadores.size()) return;
    
    Jugador& jugador = jugadores[jugadorIndex];
    Carta carta = jugador.tirarCarta(cartaIndex);
    cartasJugadas.push_back(carta);
    
    std::ostringstream oss;
    oss << "CARTA_JUGADA " << jugadorIndex << " " << carta.color << " " << carta.numero;
    notificarTodos(oss.str());
}

void Juego::finalizarRonda() {
    determinarGanadorRonda();
    rondaActual++;
    indiceJugadorInicial = (indiceJugadorInicial + 1) % jugadores.size();
}

std::string Juego::obtenerEstadoJuego() const {
    std::ostringstream oss;
    oss << "ESTADO_JUEGO " << rondaActual << "/" << totalRondas << " " << colorRonda;
    return oss.str();
}

std::string Juego::obtenerManoJugador(int jugadorIndex) const {
    if (jugadorIndex < 0 || jugadorIndex >= jugadores.size()) return "";
    
    std::ostringstream oss;
    oss << "MANO";
    for (const auto& carta : jugadores[jugadorIndex].mano) {
        oss << " " << carta.color << " " << carta.numero;
    }
    return oss.str();
}

void Juego::determinarGanadorRonda() {
    int maxPuntos = -1;
    int indiceGanador = -1;

    for (size_t i = 0; i < cartasJugadas.size(); ++i) {
        if (cartasJugadas[i].color == colorRonda && cartasJugadas[i].numero > maxPuntos) {
            maxPuntos = cartasJugadas[i].numero;
            indiceGanador = i;
        }
    }

    if (indiceGanador != -1) {
        int jugadorGanador = (indiceJugadorInicial + indiceGanador) % jugadores.size();
        jugadores[jugadorGanador].puntuacion += jugadores.size();
        jugadores[jugadorGanador].rondasGanadas++;
        
        std::ostringstream oss;
        oss << "RONDA_GANADA " << jugadorGanador << " " << jugadores[jugadorGanador].puntuacion;
        notificarTodos(oss.str());
    }
}

void Juego::notificarTodos(const std::string& mensaje) {
    if (notificar) {
        notificar(mensaje);
    }
}