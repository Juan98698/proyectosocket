#include "mazo.h"
#include <algorithm>
#include <random>

Mazo::Mazo() {
    crearMazo();
}

void Mazo::crearMazo() {
    const std::string colores[] = {"Rojo", "Azul", "Amarillo", "Verde"};
    for (const auto& color : colores) {
        for (int numero = 1; numero <= 9; ++numero) {
            cartas.push_back(Carta(color, numero));
        }
    }
    barajar();
}

void Mazo::barajar() {
    std::random_device rd;  
    std::mt19937 g(rd());   
    std::shuffle(cartas.begin(), cartas.end(), g);
}

Carta Mazo::robarCarta() {
    if (estaVacio()) {
        throw std::runtime_error("Error: Se intentó robar carta de mazo vacío");
    }
    Carta carta = cartas.back();
    cartas.pop_back();
    return carta;
}

bool Mazo::estaVacio() const {
    return cartas.empty();
}

size_t Mazo::size() const {
    return cartas.size();
}