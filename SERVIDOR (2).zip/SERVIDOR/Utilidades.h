#ifndef UTILIDADES_H
#define UTILIDADES_H

#include <iostream>
#include <limits>

void setupConsole();
void limpiarBufferEntrada();
int obtenerEntradaNumerica(int min, int max, const std::string& mensaje);

#endif