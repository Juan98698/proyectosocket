// Juego.h modificado
#ifndef JUEGO_H
#define JUEGO_H

#include "Jugador.h"
#include "Mazo.h"
#include <vector>
#include <string>
#include <functional>

class Juego {
public:
    Juego(const std::vector<std::string>& nombresJugadores);
    
    // Métodos para control remoto desde el servidor
    void iniciarRonda(const std::string& color);
    void jugarCarta(int jugadorIndex, int cartaIndex);
    void finalizarRonda();
    
    // Consultas de estado
    std::string obtenerEstadoJuego() const;
    std::string obtenerManoJugador(int jugadorIndex) const;
    std::string obtenerResultadoRonda() const;
    
    // Callbacks para notificaciones
    void setNotificacionCallback(std::function<void(const std::string&)> callback);
    
private:
    std::vector<Jugador> jugadores;
    Mazo mazo;
    std::string colorRonda;
    int rondaActual;
    int indiceJugadorInicial;
    int totalRondas;
    std::vector<Carta> cartasJugadas;
    std::function<void(const std::string&)> notificar;
    
    void determinarGanadorRonda();
    void notificarTodos(const std::string& mensaje);
};

#endif