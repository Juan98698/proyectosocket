#ifndef MAZO_H
#define MAZO_H

#include "Carta.h"
#include <vector>

class Mazo {
private:
    std::vector<Carta> cartas;

public:
    Mazo();
    void crearMazo();
    void barajar();
    Carta robarCarta();
    bool estaVacio() const;
    size_t size() const;
};

#endif