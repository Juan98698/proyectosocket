// ServidorJuego.cpp
#include <cstdlib>
#include "ServidorJuego.h"
#include "Utilidades.h"
#include <iostream>
#include <algorithm>

ServidorJuego::ServidorJuego() : servidor_fd(INVALID_SOCKET), juego(nullptr), juegoIniciado(false) {}

ServidorJuego::~ServidorJuego() {
    detener();
}

void ServidorJuego::iniciar(int puerto) {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "WSAStartup failed.\n";
        return;
    }

    // Crear el socket
    if ((servidor_fd = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
        std::cerr << "Error al crear el socket: " << WSAGetLastError() << std::endl;
        WSACleanup();
        return;
    }

    // Configurar la dirección del servidor
    sockaddr_in direccion_servidor;
    direccion_servidor.sin_family = AF_INET;
    direccion_servidor.sin_addr.s_addr = INADDR_ANY;
    direccion_servidor.sin_port = htons(puerto);

    // Enlazar el socket
    if (bind(servidor_fd, (struct sockaddr*)&direccion_servidor, sizeof(direccion_servidor)) == SOCKET_ERROR) {
        std::cerr << "Error al enlazar el socket: " << WSAGetLastError() << std::endl;
        closesocket(servidor_fd);
        WSACleanup();
        return;
    }

    // Escuchar conexiones
    if (listen(servidor_fd, SOMAXCONN) == SOCKET_ERROR) {
        std::cerr << "Error al escuchar: " << WSAGetLastError() << std::endl;
        closesocket(servidor_fd);
        WSACleanup();
        return;
    }

    std::cout << "Servidor de juego escuchando en el puerto " << puerto << "...\n";
    
    
    juego = std::make_unique<Juego>(nombresJugadores);
    juego->setNotificacionCallback([this](const std::string& mensaje) {
        this->broadcast(mensaje);
    });
    

    // Aceptar conexiones de clientes
    while (true) {
        sockaddr_in direccion_cliente;
        int addrlen = sizeof(direccion_cliente);
        SOCKET cliente_socket = accept(servidor_fd, (struct sockaddr*)&direccion_cliente, &addrlen);
        
        if (cliente_socket == INVALID_SOCKET) {
            std::cerr << "Error al aceptar conexion: " << WSAGetLastError() << std::endl;
            continue;
        }

        std::lock_guard<std::mutex> lock(mtx);
        clientes.push_back(cliente_socket);
        std::thread(&ServidorJuego::manejarCliente, this, cliente_socket).detach();
    }
}

void ServidorJuego::manejarCliente(SOCKET cliente_socket) {
    char buffer[1024];
    int bytes_recibidos;

    // Recibir nombre del jugador
    bytes_recibidos = recv(cliente_socket, buffer, sizeof(buffer), 0);
    if (bytes_recibidos <= 0) {
        closesocket(cliente_socket);
        return;
    }

    std::string nombreJugador(buffer, bytes_recibidos);
    {
        std::lock_guard<std::mutex> lock(mtx);
        nombresJugadores.push_back(nombreJugador);
        std::cout << "Jugador conectado: " << nombreJugador << std::endl;
        
        // Notificar a todos los jugadores
        broadcast("JUGADOR_CONECTADO " + nombreJugador);
        
        // Si hay suficientes jugadores, iniciar el juego
        if (nombresJugadores.size() >= 2 && !juegoIniciado) {
            juegoIniciado = true;
            juego = new Juego(nombresJugadores);
            broadcast("JUEGO_INICIADO");
        }
    }
    std::string mano = juego->obtenerManoJugador(nombresJugadores.size() - 1);
    enviarACliente(cliente_socket, mano);

    // Bucle principal de comunicación
    while (true) {
        char buffer[1024];
        int bytes_recibidos = recv(cliente_socket, buffer, sizeof(buffer), 0);
        
        if (bytes_recibidos <= 0) break;
        
        std::string comando(buffer, bytes_recibidos);
        std::istringstream iss(comando);
        std::string tipo;
        iss >> tipo;
        
        if (tipo == "TIRAR_CARTA") {
            int cartaIndex;
            iss >> cartaIndex;
            int jugadorIndex = std::distance(nombresJugadores.begin(), 
                std::find(nombresJugadores.begin(), nombresJugadores.end(), nombreJugador));
            
            juego->jugarCarta(jugadorIndex, cartaIndex);
        }
    }

    // Limpieza al desconectarse
    {
        std::lock_guard<std::mutex> lock(mtx);
        auto it = std::find(clientes.begin(), clientes.end(), cliente_socket);
        if (it != clientes.end()) {
            clientes.erase(it);
        }
        
        auto nombre_it = std::find(nombresJugadores.begin(), nombresJugadores.end(), nombreJugador);
        if (nombre_it != nombresJugadores.end()) {
            nombresJugadores.erase(nombre_it);
            broadcast("JUGADOR_DESCONECTADO " + nombreJugador);
        }
    }
    
    closesocket(cliente_socket);
}

void ServidorJuego::procesarComando(SOCKET cliente, const std::string& comando) {
    std::istringstream iss(comando);
    std::string tipo;
    iss >> tipo;

    if (tipo == "REGISTRAR") {
        // Comando: REGISTRAR [nombre_jugador]
        std::string nombre;
        iss >> nombre;
        
        std::lock_guard<std::mutex> lock(mtx);
        nombresJugadores.push_back(nombre);
        std::cout << "Jugador registrado: " << nombre << std::endl;
        
        // Notificar a todos los jugadores
        broadcast("JUGADOR_REGISTRADO " + nombre);
        
        // Iniciar juego si hay suficientes jugadores
        if (nombresJugadores.size() >= 2 && !juegoIniciado) {
            juegoIniciado = true;
            juego = std::make_unique<Juego>(nombresJugadores);
            juego->setNotificacionCallback([this](const std::string& msg) { broadcast(msg); });
            broadcast("JUEGO_INICIADO");
        }

    } else if (tipo == "TIRAR_CARTA") {
        // Comando: TIRAR_CARTA [indice_carta]
        int cartaIndex;
        iss >> cartaIndex;
        
        std::lock_guard<std::mutex> lock(mtx);
        auto it = std::find(clientes.begin(), clientes.end(), cliente);
        if (it != clientes.end()) {
            int jugadorIndex = std::distance(clientes.begin(), it);
            juego->jugarCarta(jugadorIndex, cartaIndex);
        }

    } else if (tipo == "CHAT") {
        // Comando: CHAT [mensaje]
        std::string mensaje;
        std::getline(iss, mensaje); // Captura el resto de la línea
        
        std::lock_guard<std::mutex> lock(mtx);
        auto it = std::find(clientes.begin(), clientes.end(), cliente);
        if (it != clientes.end()) {
            int jugadorIndex = std::distance(clientes.begin(), it);
            broadcast("MENSAJE_CHAT " + nombresJugadores[jugadorIndex] + ": " + mensaje);
        }

    } else if (tipo == "SALIR") {
        // Comando: SALIR
        std::lock_guard<std::mutex> lock(mtx);
        auto it = std::find(clientes.begin(), clientes.end(), cliente);
        if (it != clientes.end()) {
            int jugadorIndex = std::distance(clientes.begin(), it);
            std::string nombre = nombresJugadores[jugadorIndex];
            
            clientes.erase(it);
            nombresJugadores.erase(nombresJugadores.begin() + jugadorIndex);
            
            broadcast("JUGADOR_SALIO " + nombre);
            closesocket(cliente);
        }
    }
}

void ServidorJuego::broadcast(const std::string& mensaje) {
    for (SOCKET cliente : clientes) {
        send(cliente, mensaje.c_str(), mensaje.length(), 0);
    }
}

void ServidorJuego::enviarACliente(SOCKET cliente, const std::string& mensaje) {
    send(cliente, mensaje.c_str(), mensaje.length(), 0);
}

void ServidorJuego::detener() {
    for (SOCKET cliente : clientes) {
        closesocket(cliente);
    }
    clientes.clear();
    
    if (servidor_fd != INVALID_SOCKET) {
        closesocket(servidor_fd);
        servidor_fd = INVALID_SOCKET;
    }
    
    if (juego) {
        delete juego;
        juego = nullptr;
    }
    
    WSACleanup();
}