#include "Utilidades.h"
#ifdef _WIN32
#include <windows.h>
#endif

void setupConsole() {
    #ifdef _WIN32
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD dwMode = 0;
    GetConsoleMode(hOut, &dwMode);
    dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
    SetConsoleMode(hOut, dwMode);
    #endif
}

void limpiarBufferEntrada() {
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

int obtenerEntradaNumerica(int min, int max, const std::string& mensaje) {
    int valor;
    while (true) {
        std::cout << mensaje;
        if (!(std::cin >> valor)) {
            limpiarBufferEntrada();
            std::cout << "Entrada no válida. Por favor ingrese un número entre " 
                      << min << " y " << max << ".\n";
        } else if (valor < min || valor > max) {
            std::cout << "Valor fuera de rango. Debe ser entre " 
                      << min << " y " << max << ".\n";
        } else {
            limpiarBufferEntrada();
            return valor;
        }
    }
}