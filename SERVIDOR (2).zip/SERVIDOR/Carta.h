#ifndef CARTA_H
#define CARTA_H

#include <string>
#include <map>

class Carta {
public:
    std::string color;
    int numero;

    Carta(std::string c, int n);
    std::string toString() const;
};

#endif