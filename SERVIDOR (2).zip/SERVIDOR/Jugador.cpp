#include "Jugador.h"
#include <iostream>
#include <algorithm>

Jugador::Jugador(std::string n) : nombre(n), puntuacion(0), rondasGanadas(0) {}

void Jugador::mostrarMano() {
    std::cout << "Mano actual de " << nombre << " (" << mano.size() << " cartas):" << std::endl;
    for (size_t i = 0; i < mano.size(); ++i) {
        std::cout << i + 1 << ". " << mano[i].toString() << std::endl;
    }
}

void Jugador::mostrarManoInicial() {
    std::cout << "Mano inicial de " << nombre << " (" << manoInicial.size() << " cartas):" << std::endl;
    for (size_t i = 0; i < manoInicial.size(); ++i) {
        std::cout << i + 1 << ". " << manoInicial[i].toString() << std::endl;
    }
}

Carta Jugador::tirarCarta(int indice) {
    if (indice < 0 || indice >= static_cast<int>(mano.size())) {
        throw std::out_of_range("Índice de carta inválido");
    }
    Carta carta = mano[indice];
    mano.erase(mano.begin() + indice);
    return carta;
}

bool Jugador::tieneColor(const std::string& color) const {
    return std::any_of(mano.begin(), mano.end(), 
        [&color](const Carta& carta) { return carta.color == color; });
}

bool Jugador::tieneCartas() const {
    return !mano.empty();
}